exports.HelloGet = (req, res) =>{
    res.status(200).json({status:"OK", message:"Hello World"});
}

exports.HelloPost = (req,res) => {
    res.status(200).json({status:"OK", message:"I am post body"});
}
